import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import { getAuth, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import { getFirestore, collection, query, orderBy, getDocs, doc, getDoc, updateDoc, setDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";

const firebaseConfig={apiKey:"AIzaSyBqZSb3ZkI1QqoLGyP47ckD7eexwdStdXk",authDomain:"app-futbol-acd0f.firebaseapp.com",projectId:"app-futbol-acd0f",storageBucket:"app-futbol-acd0f.firebasestorage.app",messagingSenderId:"223446110165",appId:"1:223446110165:web:219afce6a9dac03203f75c"};
const app=initializeApp(firebaseConfig),auth=getAuth(app),db=getFirestore(app);
const $=id=>document.getElementById(id);
const esc=v=>String(v??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
const date=v=>v?.toDate?new Intl.DateTimeFormat("es-PE",{dateStyle:"medium"}).format(v.toDate()):"—";

async function isAdmin(uid){
  const snap=await getDoc(doc(db,"usuarios",uid));
  return snap.exists() && snap.data().rol==="admin";
}
function card(r){
  return `<article class="request"><div class="request-head"><div><h3>${esc(r.nombre||"Sin nombre")}</h3><p class="muted">${esc(r.email||"")} · ${esc(r.complejo||"Sin complejo")}</p></div><span class="badge">${esc(r.estado||"pending")}</span></div>
  <div class="details">
    <div class="detail"><small>DNI / documento</small>${esc(r.documento||"—")}</div>
    <div class="detail"><small>Teléfono</small>${esc(r.telefono||"—")}</div>
    <div class="detail"><small>Dirección</small>${esc(r.direccion||"—")}</div>
    <div class="detail"><small>Solicitud</small>${date(r.createdAt)}</div>
  </div>
  <div class="actions">${r.estado==="pending"?`<button class="btn approve" data-id="${esc(r.uid)}"><i class="ph-bold ph-check"></i> Aprobar</button><button class="btn btn-danger reject" data-id="${esc(r.uid)}"><i class="ph-bold ph-x"></i> Rechazar</button>`:`<span class="muted">Última actualización: ${date(r.updatedAt)}</span>`}</div></article>`;
}
async function load(){
  $("pending-list").innerHTML='<div class="empty">Cargando...</div>';
  $("history-list").innerHTML='<div class="empty">Cargando...</div>';
  try{
    const snap=await getDocs(query(collection(db,"solicitudes_duenos"),orderBy("createdAt","desc")));
    const rows=snap.docs.map(d=>({id:d.id,...d.data()}));
    const pending=rows.filter(r=>r.estado==="pending"),history=rows.filter(r=>r.estado!=="pending");
    $("pending-count").textContent=pending.length;$("approved-count").textContent=rows.filter(r=>r.estado==="approved").length;$("rejected-count").textContent=rows.filter(r=>r.estado==="rejected").length;
    $("pending-list").innerHTML=pending.length?pending.map(card).join(""):'<div class="empty">No hay solicitudes pendientes.</div>';
    $("history-list").innerHTML=history.length?history.map(card).join(""):'<div class="empty">Todavía no hay historial.</div>';
    document.querySelectorAll(".approve").forEach(b=>b.onclick=()=>changeStatus(b.dataset.id,"approved"));
    document.querySelectorAll(".reject").forEach(b=>b.onclick=async()=>{const reason=prompt("Motivo del rechazo (opcional):","");if(reason!==null)await changeStatus(b.dataset.id,"rejected",reason)});
  }catch(e){console.error(e);$("pending-list").innerHTML='<div class="empty">No se pudieron cargar las solicitudes. Revisa las reglas de Firestore.</div>'}
}
async function changeStatus(uid,status,reason=""){
  if(!confirm(status==="approved"?"¿Aprobar esta cuenta de dueño?":"¿Rechazar esta solicitud?"))return;
  try{
    await updateDoc(doc(db,"usuarios",uid),{estado:status,motivoRechazo:reason||"",approvedAt:status==="approved"?serverTimestamp():null,updatedAt:serverTimestamp()});
    await updateDoc(doc(db,"solicitudes_duenos",uid),{estado:status,motivoRechazo:reason||"",reviewedBy:auth.currentUser.uid,updatedAt:serverTimestamp()});
    await setDoc(doc(db,"canchas",uid),{estadoPublicacion:status,ownerUid:uid,updatedAt:serverTimestamp()},{merge:true});
    await load();
  }catch(e){console.error(e);alert("No se pudo actualizar la solicitud. Revisa las reglas de Firestore.");}
}
$("refresh").onclick=load;$("logout").onclick=()=>signOut(auth).then(()=>location.href="login.html");
onAuthStateChanged(auth,async u=>{
  if(!u){location.href="login.html";return}
  $("admin-email").textContent=u.email||"";
  try{if(!(await isAdmin(u.uid))){alert("No tienes permisos de administrador.");await signOut(auth);return}await load()}catch(e){console.error(e);await signOut(auth)}
});
