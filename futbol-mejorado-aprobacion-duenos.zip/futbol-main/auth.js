import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import {
  getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword,
  onAuthStateChanged, sendEmailVerification, signOut
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import {
  getFirestore, doc, setDoc, getDoc, serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyBqZSb3ZkI1QqoLGyP47ckD7eexwdStdXk",
  authDomain: "app-futbol-acd0f.firebaseapp.com",
  projectId: "app-futbol-acd0f",
  storageBucket: "app-futbol-acd0f.firebasestorage.app",
  messagingSenderId: "223446110165",
  appId: "1:223446110165:web:219afce6a9dac03203f75c"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

const $ = id => document.getElementById(id);
const emailInput = $("email"), passwordInput = $("password");
const btnLogin = $("btn-login"), btnRegister = $("btn-register"), btnAdmin = $("btn-admin");
const errorMessage = $("auth-error-message");

function setMessage(message, error = true) {
  errorMessage.textContent = message;
  errorMessage.style.color = error ? "var(--danger)" : "var(--primary-green)";
}

function registrationData() {
  return {
    nombre: $("owner-name")?.value.trim(),
    telefono: $("owner-phone")?.value.trim(),
    documento: $("owner-document")?.value.trim(),
    complejo: $("owner-business")?.value.trim(),
    direccion: $("owner-address")?.value.trim()
  };
}

function validateRegistration(data) {
  if (!data.nombre || data.nombre.length < 3) return "Escribe tu nombre completo.";
  if (!/^\d{7,12}$/.test(data.telefono.replace(/\D/g, ""))) return "Ingresa un teléfono válido.";
  if (!/^[A-Za-z0-9-]{6,15}$/.test(data.documento)) return "Ingresa un DNI/documento válido.";
  if (!data.complejo || data.complejo.length < 3) return "Indica el nombre del complejo.";
  if (!data.direccion || data.direccion.length < 5) return "Indica la dirección del complejo.";
  if (passwordInput.value.length < 8) return "La contraseña debe tener al menos 8 caracteres.";
  return null;
}

async function getProfile(uid) {
  const snap = await getDoc(doc(db, "usuarios", uid));
  return snap.exists() ? snap.data() : null;
}

function redirectByProfile(profile) {
  if (!profile) {
    setMessage("Tu cuenta no tiene un perfil válido. Contacta al administrador.");
    return;
  }
  if (profile.rol === "admin") {
    window.location.href = "admin-panel.html";
    return;
  }
  if (profile.rol === "owner") {
    if (profile.estado === "approved") {
      window.location.href = "admin.html";
    } else if (profile.estado === "rejected") {
      setMessage(`Tu solicitud fue rechazada.${profile.motivoRechazo ? " Motivo: " + profile.motivoRechazo : ""}`);
    } else {
      setMessage("Tu solicitud está pendiente de aprobación. Te avisaremos cuando el administrador la revise.", false);
    }
    return;
  }
  setMessage("Esta cuenta no tiene permisos de dueño.");
}

btnRegister?.addEventListener("click", async () => {
  const data = registrationData();
  const validation = validateRegistration(data);
  if (validation) return setMessage(validation);

  btnRegister.disabled = true;
  setMessage("Creando solicitud...", false);

  try {
    const credential = await createUserWithEmailAndPassword(auth, emailInput.value.trim(), passwordInput.value);
    const user = credential.user;

    await setDoc(doc(db, "usuarios", user.uid), {
      uid: user.uid,
      email: user.email,
      rol: "owner",
      estado: "pending",
      nombre: data.nombre,
      telefono: data.telefono.replace(/\D/g, ""),
      documento: data.documento,
      complejo: data.complejo,
      direccion: data.direccion,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });

    await setDoc(doc(db, "solicitudes_duenos", user.uid), {
      uid: user.uid,
      email: user.email,
      ...data,
      estado: "pending",
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });

    await setDoc(doc(db, "canchas", user.uid), {
      nombre: data.complejo,
      configurado: false,
      estadoPublicacion: "pending",
      ownerUid: user.uid,
      createdAt: serverTimestamp()
    });

    try { await sendEmailVerification(user); } catch (_) {}
    await signOut(auth);
    setMessage("Solicitud enviada. Revisa tu correo y espera la aprobación del administrador.", false);
  } catch (error) {
    console.error(error);
    const msg = {
      "auth/email-already-in-use": "Ese correo ya tiene una cuenta.",
      "auth/invalid-email": "El correo no es válido.",
      "auth/weak-password": "La contraseña es demasiado débil."
    }[error.code] || "No pudimos crear la solicitud. Inténtalo nuevamente.";
    setMessage(msg);
  } finally {
    btnRegister.disabled = false;
  }
});

btnLogin?.addEventListener("click", async () => {
  if (!emailInput.value || !passwordInput.value) return setMessage("Completa correo y contraseña.");
  btnLogin.disabled = true;
  setMessage("Verificando cuenta...", false);
  try {
    const credential = await signInWithEmailAndPassword(auth, emailInput.value.trim(), passwordInput.value);
    const profile = await getProfile(credential.user.uid);
    redirectByProfile(profile);
  } catch (error) {
    console.error(error);
    setMessage(error.code === "auth/invalid-credential" ? "Correo o contraseña incorrectos." : "No pudimos iniciar sesión.");
  } finally {
    btnLogin.disabled = false;
  }
});

btnAdmin?.addEventListener("click", () => {
  window.location.href = "admin-panel.html";
});

onAuthStateChanged(auth, async user => {
  if (!user) return;
  try {
    const profile = await getProfile(user.uid);
    if (profile?.rol === "owner" && profile.estado !== "approved") {
      await signOut(auth);
    }
  } catch (e) {
    console.error(e);
  }
});
